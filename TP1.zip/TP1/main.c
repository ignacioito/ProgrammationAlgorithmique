//**************************************************************************************
//Auteur : Ignacio Ito
//Fichier : TP1.c
//Date : 19 novembre 2018
//
//La structure de donnees "Queue"
//
//Vous allez implementer la structure de données Queue. Une queue suit le
//principe "premier arrive, premier servi".
//La queue sera composee de pointeurs vers des instances de la structure
//Client (dont les membres sont precises).
//La queue doit implementer les fonctionnalites offrirClient, coupDOeilTete,
//obtenirTete, longueurQueue et imprimerQueue.
//
//Les bonus sont mis en place.
//
//**************************************************************************************


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include "TP1finale.h"


int main ()
{

  printf("\n");
  epicerie();
  
}
